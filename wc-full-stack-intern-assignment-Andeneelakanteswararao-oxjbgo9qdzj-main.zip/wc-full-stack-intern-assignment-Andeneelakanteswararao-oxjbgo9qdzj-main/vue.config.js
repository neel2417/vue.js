module.exports = {
  baseUrl: process.env.NODE_ENV === 'production'
    ? '/simple-vuejs-app/'
    : '/'
}
